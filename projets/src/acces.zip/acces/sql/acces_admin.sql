create database acces;
create role acces_admin password 'Cr&a7EGrUP&!' login;
grant all on database acces to acces_admin;