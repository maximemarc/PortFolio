<?php
	$c = pg_connect('dbname=acces host=127.0.0.1 user=acces_admin password=Cr&a7EGrUP&!');
?>
