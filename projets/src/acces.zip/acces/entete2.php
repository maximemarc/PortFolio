<!DOCTYPE html>
<html>

<head>
	<title>Vision de droits</title>
	<meta name="author" content="Maxime">
	<meta name="date" content="2022-01-26T08:30:00">
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8">
	<meta http-equiv="content-style-type" content="text/css">
	<meta http-equiv="expires" content="0">
	<link href="css/vision.css" rel="stylesheet" type="text/css">
	<link href="img/favicon.png" rel="shortcut icon" type="image/png">
	<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
	<script src="js/jquery.js"></script>
	<script src="js/jquery_use.js"></script>
</head>

