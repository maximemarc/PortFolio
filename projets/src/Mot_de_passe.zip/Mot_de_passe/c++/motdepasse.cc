#include "motdepasse.h"

motdepasse::motDePasse(localeDate dateCrea,string motDePasse)
    {
    this.dateCreation = dateCrea;
    this.motDePasseHashe = motDePasse;
    }

/**
* accesseur de la date de création
* @return la date de la création du mot de passe
*/
motdepasse::localDate getDateCreation() 
    {
    return dateCreation;
    }
/**
* accesseur du mot de passe
* @return le mot de passe
*/
motdepasse::string getMotDePasseHashe() 
    {
    return motDePasseHashe;
    }
