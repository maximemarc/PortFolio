class motdepasse
    {
    private:
        localDate dateCreation;
        string motDePasseHashe;

    public:
        motDePasse(localDate,string);
        localDate getDateCreation();
        string getMotDePasseHashe();

    };
