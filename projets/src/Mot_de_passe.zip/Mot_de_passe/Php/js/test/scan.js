for (var i = 0; i < longueur_val_input; i++)
	{
	var v = val_input[i];
	// Vérification que le mot de passe contient une minuscule	
	if (v >= 'a' && v <= 'z')
		{
        c2 = 1;
		}	
	// Vérification que le mot de passe contient une Majuscule	
    if (v >= 'A' && v <= 'Z')
		{
		c3 = 1;
		}	
	// Vérification que le mot de passe contient un chiffre	
    if (v >= '0' && v <= '9')
		{
		c4 = 1;
		}
	// Vérification que le mot de passe contient un caractère spécial	
    if (v == '!' || v == '?' || v == '_' || v == '*')
		{
		c5 == 1;
		}

        //OR
	if (v >= '!' && v <= '/' || v >= ':' && v <= '@' || v >= '[' && v <= '`' || v >= '{' && v <= '~')
        {
	    c5 = 1;
	    }       	
    }
	