var color = ['darkred', 'red', 'orange', 'yellow', 'lightgreen', 'green'];

function verif()
	{
	// Je récupère la valeur saisie par l'utilisateur
	var mon_input = document.getElementById('inp');
	var val_input = mon_input.value;
	// Je récupère la taille de la saisie en utilisant
	// la propriété length de l'objet de type [string]
	var longueur_val_input = val_input.length;
	var total = 0;// nombre de conditions validées
	// j'ai 5 conditions à respecter, je considère qu'elles 
	// sont fausses au départ
	var c1 = 0, c2 = 0, c3 = 0, c4 = 0, c5 = 0, c6 = 0;
	
	if (longueur_val_input >= 8)
		{
		c1 = 1;
		}		
	// Je parcours la saisie en récupérant chaque lettre
	// du mot 
	for (var i = 0; i < longueur_val_input; i++)
		{
		var v = val_input[i];
		// Vérification que le mot de passe contient une minuscule	
		if (v >= 'a' && v <= 'z')
			{
			c2 = 1;
			}
		else
			{	
			// Vérification que le mot de passe contient une Majuscule	
			if (v >= 'A' && v <= 'Z')
				{
				c3 = 1;
				}
			else
				{
				// Vérification que le mot de passe contient un chiffre	
				if (v >= '0' && v <= '9')
					{
					c4 = 1;
					}
				else
					{	
					// Vérification que le mot de passe contient un caractère spécial	
					if (v == '!' || v == '?' || v == '_' || v == '*')
						{
						c5 = 1;
						}
					else
						{
						c6 = -1;
						}
					}	
				}	
			}	
		}
	total = c1 + c2 + c3 + c4 + c5 + c6;
	mon_input.style.backgroundColor = color[total];
	if (total == 5) 
		{
		document.getElementById('sub').style.display = 'block';
		}
	else 
		{
		document.getElementById('sub').style.display = 'none';
		}
	}