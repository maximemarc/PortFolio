begin transaction;

create table mdp
	(
	id_mdp serial primary key,
	mdp varchar(20),
	md5 varchar(32)
	);

commit;
