create database mdp;
create role mdp_admin password 'admin' login;
grant all on database mdp to mdp_admin;