<?php
	// Je récupére la valeur transmise en méthode GET
	// (idem si c'est POST)
	$mdp = $_GET['mdp'];
	$v = 0; // nombre de conditions validées
	// j'ai 5 conditions à respecter, je considaire qu'elles
	// sont fausses au départ
	$c1 = $c2 = $c3 = $c4 = $c5 = $c6 = 0;
	$taille = 0;
	while($lettre = $mdp[$taille])
		{
		if($lettre >='a' && $lettre <='z')
			{
			$c2 = 1;
			}
		else
			{
			if ($lettre >='A' && $lettre <='Z')
				{
				$c3 = 1;
				}
			else
				{
				if ($lettre >='0' && $lettre <='9')
					{
					$c4 = 1;
					}
				else
					{
					if($lettre == '?' || $lettre == '!' || $lettre == '_' || $lettre == '*')
						{
						$c5 = 1;
						}
					else
						{
						$c6 = -1;
						}
					}
				}
			}
		$taille++;
		}
	if($taille >= 8)
		{
		$c1=1;
		}
	$v = $c1 + $c2 + $c3 + $c4 + $c5 + $c6;
	if($v == 5)
		{
		// $v = 5 donc le mot de passe est conforme
		// on le stocke dans la base et on informe l'utilisateur
		$conn = pg_connect('host=127.0.0.1 dbname=mdp user=mdp_admin password=admin');
		$string_req = "insert into mdp(mdp, md5) values ('";
		$string_req .= $mdp;
		$string_req .= "', '";
		$string_req .= md5($mdp);
		$string_req .= "')";
		$req = pg_query($string_req);
		pg_close($conn);
		if($req)
			{
			echo 'Le mot de passe est stocké dans la base.';
			}
		else
			{
			echo 'Erreur d\'insertion dans la base.';
			}
		}
	else
		{
		// $v !=5 donc le mot de passe est illègal
		// on renvoie l'utilisateur sur la page de saisie 
		// avec un message d'erreur
		echo $v;
	 	}
?>