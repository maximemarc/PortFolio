<?php
    $mdp = $_GET['mdp'];
    echo preg_match('/[a-z]+/', $mdp, $matches);
    var_dump($matches);
?>