/* Combinaison secrète - Jeu de réflexion en JavaScript ayant pour objectif 
   de s'initier à JavaScript - BTS SIO Reims - Fabio Pasqualini 2020     */  

var secret = [0,1,2,3,4,5,6,7];
var element_courant = 0;
var nb_coups = 100;

function debut()
	{
	for(a=0; a<100; a++)
		{
		i = Math.floor(Math.random()*8);
		j = Math.floor(Math.random()*8);
		temp = secret[i];
		secret[i] = secret[j];
		secret[j] = temp;
		}
	// On remet à zéro le nombre de coups
	nb_coups = 0;
	// On efface le message éventuel
	var e = document.getElementById("mess");
	e.innerHTML = '';
	// On remet à zéro le bloc de proposition
	var propo = document.getElementById('propo');
	propo.innerHTML = '';
	// On appelle la création d'une ligne permettant à l'utilisateur de faire une proposition
	ligne_sup();
	}

function drag(c)
	{
	element_courant = c;
	}

function permettre_drop() 
	{
   event.preventDefault();
	}

function drop(e)
	{
	event.preventDefault();
	e.setAttribute("src", element_courant+".png");
	}

// Cette fonction permet d'afficher une ligne supplémentaire
function ligne_sup()
	{
	// On récupère le conteneur
	var propo = document.getElementById('propo');
	// On crée un élément HTML saut de ligne 
	var br = document.createElement('br');
	// On ajoute ce saut de ligne au conteneur
	propo.appendChild(br);	
	// Nous allons ensuite effectuer 5 fois l'ajout d'un élément <img>
	for (var i=0; i<5; i++)
		{
		// Création de l'élément HTML <img>
		var ima = document.createElement('img');
		// On ajoute les deux événements
		ima.setAttribute('ondragover', 'permettre_drop()');
		ima.setAttribute('ondrop', 'drop(this)');
		// On ajoute l'élément créé au conteneur
		propo.appendChild(ima);	
		}
	// On fait de même pour le bouton [?]
	var ima = document.createElement('img');
	ima.setAttribute('src', 'question.png');
	ima.setAttribute('onclick', 'evaluer(this)');
	propo.appendChild(ima);	
	}

// Fonction d'évaluation d'une proposition
function evaluer(t)
	{
	var proposition = [];
	var precedent = t.previousSibling;
	for(var i=0; i<5; i++)
		{
		if(precedent.attributes.length == 3)
			{ 
			proposition.push(precedent.getAttribute('src').charAt(0));
			}
		precedent = precedent.previousSibling;
		}
	proposition = proposition.reverse();

	if(proposition.length == 5)
		{	
		var precedent = t.previousSibling;
		for(var i=0; i<5; i++)
			{
			precedent.removeAttribute('ondrop');		
			precedent.removeAttribute('ondragover');
			precedent = precedent.previousSibling;
			}
		t.removeAttribute('onclick');
		
		var nb_bien_places = 0;
		var nb_mal_places = 0;
		for (var i=0; i<5; i++) 
			{
			if (secret[i] == proposition[i]) 
				{
				nb_bien_places++;		
				}
			else 
				{
				var trouve = false;			
				for (var j=0; j<5; j++) 
					{
					if (secret[i] == proposition[j]) 
						{
						trouve = true;		
						}
					}
				if(trouve)
					{
					nb_mal_places++;				
					}
				}
			}		

		var propo = document.getElementById('propo'); 
		for (var i=0; i<nb_bien_places; i++)
			{
			var ima = document.createElement('img');
			ima.setAttribute('src','r1.png');
			propo.appendChild(ima);	
			} 
		for (var i=0; i<nb_mal_places; i++)
			{
			var ima = document.createElement('img');
			ima.setAttribute('src','r0.png');
			propo.appendChild(ima);	
			} 

		nb_coups++;
		if (nb_bien_places == 5)
			{
			var message = 	"Bravo ! Vous avez gagné en <span>" + nb_coups + "</span> coups !";
			var d = document.getElementById('mess').innerHTML = message;		
			}	
		else 
			{
			ligne_sup();
			}
		}
	else 
		{
		alert("Vous n'avez pas une proposition complète !");
		}	
	}