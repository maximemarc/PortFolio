begin transaction;

create table projet
	(
	id_projet integer primary key,
	titre varchar(50),
	date_p date
	);
	
create table utilisateur
	(
	id_user integer primary key,
	nom varchar(20),
	prenom varchar(20),
	mail varchar(100),
	login varchar(20),
	mdp varchar(32),
	admin boolean
	);
	
create table droit
	(
	id_user integer,
	id_projet integer,
	droit char(1) check (droit in ('L', 'E', 'R','C')),
	primary key (id_user,id_projet)
	);
	
create table intervention
	(
	id_projet integer references projet(id_projet),
	numero_ordre integer,
	id_user integer references utilisateur(id_user),
	date_i date,
	primary key (id_projet,numero_ordre)
	);
	
create table etat
	(
	id_etat integer primary key,
	libelle varchar(50),
	pos integer
	);
		
create table taches
	(
	id_taches integer primary key,
	nom varchar(20),
	description varchar(100),
	important integer,
	date_debut date,
	date_fin date,
	id_projet integer references projet(id_projet),
	id_etat integer references etat(id_etat)
	);	
	
create table document
	(
	id_document integer primary key,
	nom varchar(20),
	description varchar(100),
	id_tac integer references taches(id_taches)
	);	
	





commit;