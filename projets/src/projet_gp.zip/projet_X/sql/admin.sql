create database gp;
create role gp_admin password 'admin' login;
grant all on database gp to gp_admin;
