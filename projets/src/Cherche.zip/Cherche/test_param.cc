#include<iostream>

int main(int nb_param, char ** param, char ** env )
	{
	std::cout<<"Nombre de paramètres : "<<nb_param<<"\n";
	int i = 0;
	while( i < nb_param )
		{
		std::cout<<"param["<<i<<"] contient "<<param[i]<<".\n";
		i++;		
		}
	}

