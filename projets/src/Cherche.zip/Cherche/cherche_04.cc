//Fabio Pasqualini 10/2021 - étapes de l'écriture de cherche <mot> <fichier>
/* J'ouvre un fichier déjà écrit qui est passé en paramètre et je lis (j'utilise la méthode get()) chaque lettre
et je l'affiche à l'écran. Je tape la commande : cherche texte.txt */

#include<fstream>
#include<iostream>


using namespace std;

int main(int a,char**b)
	{
	if(a >= 2)
		{
		fstream f;
		f.open(b[1], ios::in);
		if (f.is_open())
			{
			char c;
			while(f.get(c))
				{
				cout<<c;
				}
			cout<<"\n";
			f.close();
			if (a > 2)
				{
				cerr<<"\n\n vous avez mis trop de parametre mais on prend quand meme le parametre numero 2 \n";
				}
			}
		else
			{
			cerr << "Impossible d'ouvrir le fichier ! \n";
			}
		}
	else
		{
		cerr<<"Attention la commande n'attend qu'un argument, le nom du fichier à lire.\n";
		cerr<<"De ce fait, les autres arguments seront ignorés.\n";
		}
	}

