//Fabio Pasqualini 10/2021 - étapes de l'écriture de cherche <mot> <f>
/* J'ouvre un f déjà écrit (texte.txt) et je lis (lecture formatée) chaque mot
(au sens programmation, chaque ensemble de caractères séparés par une espace)
et je l'affiche à l'écran. */

#include<fstream>
#include<iostream>
#include <string>

using namespace std;

int main()
	{
    ifstream f;
	f.open("texte.txt", ios::in);
 
	//vérification
    if(f.is_open())
        {
 		string s;
        while(getline(f, s))
        	{
        	cout << s << endl;
        	}
        f.close();
        }
    else
		{
        cerr << "Impossible d'ouvrir le fichier ! \n";
		}
	}


