//Fabio Pasqualini 10/2021 - étapes de l'écriture de cherche <mot> <fichier>
/* J'ouvre un fichier déjà écrit (texte.txt) et je lis (j'utilise la méthode get()) chaque caractère
et je l'affiche à l'écran. */

#include<fstream>
#include<iostream>


using namespace std;

int main()
	{
	fstream f;
	f.open("texte.txt",ios::in);
	if (f.is_open())
		{
		char c;
		f.get(c);
		while(!f.eof())
			{
			cout<<c;
			f.get(c);
			}
		cout<<"\n";
		f.close();
		}
	else
		{
		cerr << "Impossible d'ouvrir le fichier ! \n";
		}
	}
