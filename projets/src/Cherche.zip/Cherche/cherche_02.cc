//Fabio Pasqualini 10/2021 - étapes de l'écriture de cherche <mot> <fichier>
/* J'ouvre un fichier déjà écrit (texte.txt) et je lis (j'utilise la méthode getline()) chaque ligne
et je l'affiche à l'écran. */

#include<fstream>
#include<iostream>

using namespace std;

int main()
	{
	fstream f;
	f.open("texte.txt",ios::in);
	if (f.is_open())
		{
		char s[2000];//limitation du nombre de caractère qui peut entrainer une erreur
		s[1999]=0;
		while(f.getline(s,1999))
			{
			cout<<s<<'\n';
			}
		f.close();
		}
	else
		{
		cerr << "Impossible d'ouvrir le fichier ! \n";
		}
	}


