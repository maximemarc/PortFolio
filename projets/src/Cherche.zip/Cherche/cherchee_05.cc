//Fabio Pasqualini 10/2021 - étapes de l'écriture de cherche <mot> <fichier>
/* J'ouvre un fichier déjà écrit qui est passé en paramètre et je lis (j'utilise la méthode get()) chaque lettre
et je l'affiche à l'écran. Je récupère aussi le mot à chercher et je l'affiche. Je tape la commande : cherche mot texte.txt */

#include<fstream>
#include<iostream>


using namespace std;

int main(int nb_param, char ** param )
	{
	if(nb_param < 3)
		{
		cerr<<"Attention la commande attend 2 arguments, le mot à chercher et le nom du fichier à lire.\n";
		cerr<<"Exemple : cherche mon_mot mon_fichier.txt\n";
		}		
	else
		{
		if(nb_param > 3)
			{
			cerr<<"Attention la commande n'attend que 2 arguments, le mot à chercher et le nom du fichier à lire.\n";
			cerr<<"De ce fait, les autres arguments seront ignorés.\n";
			}		
		fstream f;
		f.open(param[2], ios::in);
		// Je récupère le premier caractère du mot à chercher
		char ch = param[1][0];
		if (f.is_open())	
			{
			// TRAITEMENT
			// fonctionne avec le bash
			char coul[]="\033[7;31m";			
			char orig[]="\033[7;0m";			
			char c;
			while(f.get(c))
				{
				if(c!=ch)
					{
					cout<<c;
					}
				else
					{
					cout<<coul<<c<<orig;					
					}
				}
			cout<<"\n";
			f.close();
			}
		else
			{
			cerr<<"L'ouverture du fichier "<<param[1]<<" a échouée.\n";
			}		
		}	
	}