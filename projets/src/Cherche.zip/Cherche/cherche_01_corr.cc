//Fabio Pasqualini 10/2021 - étapes de l'écriture de cherche <mot> <fichier>
/* J'ouvre un fichier déjà écrit (texte.txt) et je lis (lecture formatée) chaque mot
(au sens programmation, chaque ensemble de caractères séparés par une espace)
et je l'affiche à l'écran. */

#include <fstream>
#include <iostream>
#include <string>

using namespace std;

int main()
	{
	fstream f;
	f.open("texte.txt",ios::in);
	string s;
	f>>s;	
	while(!f.eof())
		{
		cout<<s<<" ";
		f>>s;	
		}
	cout<<endl;
	f.close();
	}

