package fr.evosial.commands;

import org.javacord.api.event.message.MessageCreateEvent;

public interface CommandExecutor {
    void run(MessageCreateEvent messageCreateEvent, Commands commands, String[] args);
}
