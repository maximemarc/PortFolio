package fr.evosial.commands;

public class Commands {

    private String id,description;
    private String[] alias;

    private CommandExecutor commandExecutor;

    public Commands(String id, String description, CommandExecutor commandExecutor, String... alias) {
        this.id = id;
        this.description = description;
        this.alias = alias;
        this.commandExecutor = commandExecutor;
    }

    public String getId() {
        return id;
    }

    public String getDescription() {
        return description;
    }

    public String[] getAlias() {
        return alias;
    }

    public CommandExecutor getCommandExecutor() {
        return commandExecutor;
    }
}
