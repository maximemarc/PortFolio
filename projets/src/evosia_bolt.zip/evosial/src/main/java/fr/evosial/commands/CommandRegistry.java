package fr.evosial.commands;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Optional;

public class CommandRegistry
    {
    private ArrayList<Commands> commands;

    public CommandRegistry()
        {
        this.commands = new ArrayList<Commands>();
        }

    public void addCommand(Commands cmd)
        {
        commands.add(cmd);
        }


    public void deleteCommand(String id)
        {
        commands.removeIf((cmd)->cmd.getId().equalsIgnoreCase(id));
        }

    public Optional<Commands> getByAlias(String alias)
        {
        for (Commands command:commands)
            {
            if (Arrays.asList(command.getAlias()).contains(alias))
                {
                return Optional.of(command);
                }
            }
        return Optional.empty();
        }
    }
