package fr.evosial.commands;

import org.javacord.api.event.message.MessageCreateEvent;


public class CommandPing implements CommandExecutor {
    @Override
    public void run(MessageCreateEvent messageCreateEvent, Commands commands, String[] args) {
        messageCreateEvent.getChannel().sendMessage("pong").thenAccept(message ->{
        long unixBot = message.getCreationTimestamp().toEpochMilli();
        long unixUser= messageCreateEvent.getMessage().getCreationTimestamp().toEpochMilli();
        long ping = unixBot - unixUser;
        messageCreateEvent.getChannel().sendMessage(String.valueOf(ping));
        });


    }
}
