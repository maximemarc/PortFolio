package fr.evosial;

import com.google.gson.Gson;
import fr.evosial.commands.MessageManager;
import org.javacord.api.DiscordApi;
import org.javacord.api.DiscordApiBuilder;
import org.javacord.api.util.logging.FallbackLoggerConfiguration;

import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;


public class Main {

    public static void main(String[] args) throws IOException {
        System.out.println("Démarrage du bot \n");
        FallbackLoggerConfiguration.setTrace(false);
        Gson gson = new Gson();
        System.out.println("chargement du fichier configuation\n");
        Path conf = Paths.get(System.getProperty("user.dir"), "config.json");
        Reader reader = Files.newBufferedReader(conf);
        if (reader.ready())
            {
            HashMap map = gson.fromJson(reader, HashMap.class);
            reader.close();
            System.out.println("lecture du fichier\n");
            DiscordApi Api = new DiscordApiBuilder().setToken(map.get("tokens").toString()).login().join();

            Api.addMessageCreateListener(MessageManager::create);
            }
        else
            {
            System.out.println("impossible de lire le fichier");
            }
      }
}
