package fr.evosial.commands;

import org.javacord.api.entity.message.embed.EmbedBuilder;
import org.javacord.api.event.message.MessageCreateEvent;

import java.awt.*;

public class Commandtest implements CommandExecutor {
    @Override
    public void run(MessageCreateEvent messageCreateEvent, Commands commands, String[] args) {
        EmbedBuilder embed = new EmbedBuilder()
                .setTitle("Test")
                .setAuthor("Maxime")
                .setDescription("test")
                .addField("test1","test est oui",true)
                .addField("test2","test est oui",true)
                .addField("test1","test est oui")
                .addField("test2","test est oui")
                .setFooter("Bisous")
                .setColor(Color.BLUE);
        messageCreateEvent.getChannel().sendMessage(embed);
    }
}
