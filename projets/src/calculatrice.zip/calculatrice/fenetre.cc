#include "fenetre.h"
#include "ui_fenetre.h"

fenetre::fenetre(QWidget *parent): QMainWindow(parent), ui(new Ui::fenetre)
    {
    ui->setupUi(this);
    init();
    touches = new QPushButton[17];

    for(int i=0; i< 17; i++)
        {
        touches[i].setFixedSize(50,50);
        }
    //chiffre
    for(int i=0; i< 10; i++)
        {
        QString s;
        s.setNum(i);
        touches[i].setText(s);
        connect(&touches[i],SIGNAL(clicked()),this,SLOT(nombre()));
        int l = ((9 - i)/3)+1;
        int c = ((i-1)%3)+1;
        ui->grille->addWidget(&touches[i],l,c);
        }
    ui->grille->addWidget(&touches[0],4,1);

    //calcul
    touches[10].setText("AC");
    ui->grille->addWidget(&touches[10],0,4);
    connect(&touches[10],SIGNAL(clicked()),this,SLOT(init()));
    touches[11].setText("/");
    ui->grille->addWidget(&touches[11],1,4);
    touches[12].setText("*");
    ui->grille->addWidget(&touches[12],2,4);
    touches[13].setText("-");
    ui->grille->addWidget(&touches[13],3,4);
    touches[14].setText("+");
    ui->grille->addWidget(&touches[14],4,4);
    touches[15].setText(".");
    ui->grille->addWidget(&touches[15],4,2);
    touches[16].setText("=");
    ui->grille->addWidget(&touches[16],4,3);
    }

fenetre::~fenetre()
    {
    delete ui;
    }

void fenetre::init()
    {
    operande1.clear();
    operande2.clear();
    operande3.clear();
    }

void fenetre::nombre()
    {
    QPushButton * bouton = qobject_cast<QPushButton *>(sender());
    if(ui->affichage->text()== "")
        {
        ui->affichage->setText(bouton->text());
        }
    else
        {
        QString f = ui->affichage->text();
        ui->affichage->setText(f + bouton->text());
        }
    }
