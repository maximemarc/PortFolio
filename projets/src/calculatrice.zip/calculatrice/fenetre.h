#ifndef FENETRE_H
#define FENETRE_H

#include <QMainWindow>
#include <QPushButton>
#include <QString>

QT_BEGIN_NAMESPACE
namespace Ui { class fenetre; }
QT_END_NAMESPACE

class fenetre : public QMainWindow
    {
    Q_OBJECT

    private:
        Ui::fenetre * ui;
        QString operande1;
        QString operande2;
        QString operande3;
        QPushButton * touches;


    public:
        fenetre(QWidget *parent = nullptr);
        ~fenetre();


    public slots:
        void nombre();
        void init();
    };

#endif // FENETRE_H
