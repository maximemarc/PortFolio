create database stock encoding 'UTF8';
create role stock_admin password 'admin' login;
grant all on database stock to stock_admin;