﻿begin transaction;

create table utilisateur
    (
    id_user             integer PRIMARY KEY,
    date_inscription    timestamp,
    nom                 varchar(20) not null,
    prenom              varchar(20) not null,
    mail                varchar(50) not null,
    telephone           varchar(11),
    motdepasse          varchar(50) not null,
    solde               numeric(10,2) DEFAULT 0::numeric(10,2),
    admin               boolean DEFAULT false
    );

create table produit
    (
    id_prod             serial PRIMARY KEY,
    dateajout           timestamp,
    nom                 varchar(50) unique,
    description         varchar(100),
    quant               numeric(10) not null,
    nb_ventes           integer,
    prix                numeric(10,2)
    );

create table achat
    (
    id_achat            serial PRIMARY KEY,
    id_user             integer references utilisateur(id_user),
    id_prod             integer references produit(id_prod),
    quant               integer not null,
    date_transaction    timestamp,
    );


create table promo_code
    (
    id_promo            serial PRIMARY KEY,
    datecrea            timestamp,
    datefin             timestamp,
    pourcentage         numeric(4,2),
    limite              integer,
    actif               boolean DEFAULT TRUE,
    general             boolean DEFAULT false
    );

create table affectation_promo
    (
    id_prod integer references produit(id_prod),
    id_promo integer references promo_code(id_promo),
    PRIMARY KEY(id_promo,id_prod)
    );


commit;