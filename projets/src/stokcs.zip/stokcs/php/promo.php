<?php
class promo
    {
    function crea_promo($pourcentage,$datefin,$limite = null, $general = false,$actif = true, $id_prod = null)
        {
        $jour = date('Y-m-d');
        $req = "INSERT INTO achat (dateajout,datefin,pourcentage,limite,actif,general)VALUES('".$jour."','".$datefin."','".$pourcentage."',".$limite.",".$actif.",".$general.")";
        $insert = pg_query($req);
        if($insert)
            {
            if($id_prod != null)
                {
                $req = "SELECT MAX(id_promo) FROM produit";
                $max = pg_fetch_row(pg_query($req))[0];
                if($max != null)
                    {
                    $req = "INSERT INTO affectation_promo (id_promo,id_prod)VALUES(".$max.",".$id_prod.")";
                    $insert = pg_query($req);  
                    if(!$insert)
                        {
                        echo "erreur lors de l'affection du promo code";
                        }
                    }
                }
                
            }
        else
            {
            echo "erreur lors de la création du produit";
            }
       
        }

    function set_limit_promo($id,$limit)
        {
        $req = "UPDATE table SET limit = ".$limit." WHERE id_promo =".$id;
        $update = pg_query($req);
        if(!$update)
            {
            echo "erreur lors de l'update de la limite de la promo";
            }
        }

    function set_actif_promo($id)
        {
        $req = "SELECT actif FROM promo WHERE id_promo =".$id;
        $actif = pg_fetch_row(pg_query($req))[0];
        if($actif == 'f')
            {
            $actif = 't';
            }
        else
            {
            $actif = 'f';
            }
        $req = "UPDATE table SET actif = ".$actif." WHERE id_promo =".$id;
        $update = pg_query($req);
        if(!$update)
            {
            echo "erreur lors de l'update de l'etat de la promo";
            }
        
        }

    function set_fin_promo($id,$date)
        {
        $req = "UPDATE table SET datefin = ".$date." WHERE id_promo =".$id;
        $update = pg_query($req);
        if(!$update)
            {
            echo "erreur lors de l'update de la date de fin du code promo";
            }
        
        }

    function get_promo($id)
        {    
        $req = 'select * from achat where id_achat = '.$id;
        $exe = pg_query($req);
        $tab = pg_fetch_all($exe);
        $array = array();
        foreach($tab as $t)
            {
            $array += array($t['id_user'],$t['id_prod'],$t['quant']);
            }
        return $array;
        }
        
    
    function get_limit_promo($id)
        {
            $req = "SELECT dateajout FROM produit WHERE id_produit =".$id;
            $date = pg_fetch_row(pg_query($req))[0];
            return $date;
        }

    function get_actif_promo($id)
        {

        }

    function get_debut_promo($id)
        {
        
        }

    function get_fin_promo($id)
        {
        
        }
    }
?>