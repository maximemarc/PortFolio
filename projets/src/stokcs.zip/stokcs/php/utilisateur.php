<?php
//class utilisateur
    //{
    function utilisateur($nom,$prenom,$mail,$telephone = null,$motdepasse,$admin = false)
        {
        $jour = date('Y-m-d');
        $req = "SELECT MAX(id_user)+1 FROM utilisateur";
        $max = pg_fetch_row(pg_query($req))[0];
        $req = "INSERT INTO achat (id_user,date_inscription,nom,prenom,mail,telephone,motdepasse,solde,admin)
            VALUES(".$max.",'".$jour."','".$nom."','".$prenom."','".$mail."','".$telephone."',
            MD5('".$motdepasse."'),".$admin.")";
        $insert = pg_query($req);
        if(!$insert)
            {
            echo "erreur lors de la création de l'utilisateur";
            }
        }

    function get_solde($id)
        {
        $req = "SELECT solde FROM utilisateur WHERE id_user =".$id;
        $solde = pg_fetch_row(pg_query($req))[0];
        if($solde == null)
            {
            $solde = 0;
            }
        return $solde;
        }

    function set_solde($id,$solde)
        {
        $req = "UPDATE table SET solde = ".$solde." WHERE id_user =".$id;
        $update = pg_query($req);
        if(!$update)
            {
            echo "erreur lors de l'update du solde de l'utilisateur";
            }
        }

    function add_solde($id,$solde)
        {
        $s = get_solde($id);
        $s += $solde;
        return $s;
        }

    function get_nom($id)
        {
        $req = "SELECT nom FROM utilisateur WHERE id_user =".$id;
        $nom = pg_fetch_row(pg_query($req))[0];
        return $nom;
        }

    function get_prenom($id)
        {
        $req = "SELECT prenom FROM utilisateur WHERE id_user =".$id;
        $prenom = pg_fetch_row(pg_query($req))[0];
        return $prenom;
        }

    function get_mail($id)
        {
        $req = "SELECT mail FROM utilisateur WHERE id_user =".$id;
        $mail = pg_fetch_row(pg_query($req))[0];
        return $mail;
        }
    
    function get_telephone($id)
        {
        $req = "SELECT telephone FROM utilisateur WHERE id_user =".$id;
        $tel = pg_fetch_row(pg_query($req))[0];
        return $tel;
        }

    function set_new_mot_de_passe($id,$motdepasse,$motdepasse2,$motdepasse3)
        {
        $req = "SELECT motdepasse FROM utilisateur WHERE id_user =".$id."AND motdepasse = MD5('".$motdepasse."')";
        $mdp = pg_fetch_row(pg_query($req))[0];
        if($mdp != null)
            {
            if(md5($motdepasse2) == md5($motdepasse3))
                {
                if(md5($motdepasse) != md5($motdepasse2))
                    {
                    $req = "UPDATE table SET motdepasse = MD5('".$motdepasse2."') WHERE id_user =".$id;
                    $update = pg_query($req);
                    if(!$update)
                        {
                        echo "erreur lors de l'update de l'utilisateur";
                        }
                    }
                else
                    {
                    echo "vous n'avez pas changer de mot de passe, modification annule";
                    }
                }
            else
                {
                echo "le nouveau mot de passe et celui de comfirmation sont diffèrents, modification annule";
                }
            }
        else
            {
            echo "Mot de passe incorrect";
            }
        }

    function set_admin($id)
        {
        $req = "SELECT admin FROM utilisateur WHERE id_user =".$id;
        $admin = pg_fetch_row(pg_query($req))[0];
        if($admin == 'f')
            {
            $admin = 't';
            }
        else
            {
            $admin = 'f';
            }
        $req = "UPDATE table SET admin = ".$admin." WHERE id_user =".$id;
        $update = pg_query($req);
        if(!$update)
            {
            echo "erreur lors de l'update de l'utilisateur";
            }
        }
    //}
?>