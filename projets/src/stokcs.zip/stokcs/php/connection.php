<?php
        //$con = pg_connect('host=127.0.0.1 dbname=stock user=stock_admin password=admin');
function connect($host,$name,$user,$password)
        {
        $con = pg_connect('host='.$host.' dbname='.$name.' user='.$user.' password='.$password);
        if($con)
            {
            return $con;
            }
        else
            {
            echo 'Erreur de connection à la base de donnée';
            pg_close();
            }   
        }
?>