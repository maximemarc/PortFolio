<?php
//class produit
    //{
    
    function produit($nom,$description,$quant,$prix)
        {
        $jour = date('Y-m-d');
        $req = "INSERT INTO achat (dateajout,nom,description,quant,prix)VALUES('".$jour."','".$nom."','".$description."',".$quant.",".$prix.")";
        $insert = pg_query($req);
        if(!$insert)
            {
            echo "erreur lors de la création du produit";
            }
        }

    function set_nom_produit($id,$nom)
        {
        $req = "UPDATE table SET nom = '".$nom."' WHERE id_produit =".$id;
        $update = pg_query($req);
        if(!$update)
            {
            echo "erreur lors de l'update du nom du produit";
            }
        }

    function set_description_produit($id,$desc)
        {
        $req = "UPDATE table SET description = '".$desc."' WHERE id_produit =".$id;
        $update = pg_query($req);
        if(!$update)
            {
            echo "erreur lors de l'update de la description du produit";
            }
        }

    function set_quant_produit($id,$quant)
        {
        $req = "UPDATE table SET quant = ".$quant." WHERE id_produit =".$id;
        $update = pg_query($req);
        if(!$update)
            {
            echo "erreur lors de l'update de la quantité du produit";
            }
        }

    function set_prix_produit($id,$prix)
        {
        $req = "UPDATE table SET prix = ".$prix." WHERE id_produit =".$id;
        $update = pg_query($req);
        if(!$update)
            {
            echo "erreur lors de l'update du prix du produit";
            }
        }        

    function get_nom_produit($id)
        {
        $req = "SELECT nom FROM produit WHERE id_produit =".$id;
        $nom = pg_fetch_row(pg_query($req))[0];
        return $nom;
        }

    function get_description_produit($id)
        {
        $req = "SELECT description FROM produit WHERE id_produit =".$id;
        $desc = pg_fetch_row(pg_query($req))[0];
        return $desc;
        }

    function get_quant_produit($id)
        {
        $req = "SELECT quant FROM produit WHERE id_produit =".$id;
        $quant = pg_fetch_row(pg_query($req))[0];
        return $quant;
        }

    function get_prix_produit($id)
        {
        $req = "SELECT prix FROM produit WHERE id_produit =".$id;
        $prix = pg_fetch_row(pg_query($req))[0];
        return $prix;
        }

    function get_nb_vente_produit($id)
        {
        $req = "SELECT nb_vente FROM produit WHERE id_produit =".$id;
        $nb_vente = pg_fetch_row(pg_query($req))[0];
        if($nb_vente==null)
            {
            $nb_vente = 0;
            }
        return $nb_vente;
        }

    function get_date_ajout_produit($id)   
        {
        $req = "SELECT dateajout FROM produit WHERE id_produit =".$id;
        $date = pg_fetch_row(pg_query($req))[0];
        return $date;
        }

    function get_image_produit($id)   
        {
        $image = $id."produit.png";
        return $image;
        }

    function add_nb_vente_produit($id)
        {
        $nb_vente = get_nb_vente_produit($id);
        $nb_vente++;
        
        $req = "UPDATE table SET nb_vente = ".$nb_vente." WHERE id_produit =".$id;
        $update = pg_query($req);
        if(!$update)
            {
            echo "erreur lors de l'update du nombres de ventes du produit";
            }
        }
   // }
?>