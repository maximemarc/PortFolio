<?php
class achat
    {
    function achat($id_user,$id_prod,$quant)
        {
        $jour = date('Y-m-d');
        $req = "insert into achat (id_user,id_prod,quant,date_transaction)values(".$id_user.",".$id_prod.",".$quant.",".$jour.")";
        $insert = pg_query($req);
        if(!$insert)
            {
            echo "erreur lors de l'achat des produit";
            }
        }

    function get_achat($id)
        {
        $req = 'select * from achat where id_achat = '.$id;
        $exe = pg_query($req);
        $tab = pg_fetch_all($exe);
        $array = array();
        foreach($tab as $t)
            {
            $array += array($t['id_user'],$t['id_prod'],$t['quant']);
            }
        return $array;
        }

    function get_user_achat($id)
        {
        $req = "SELECT achat FROM achat WHERE id_user =".$id;
        $achat = pg_fetch_row(pg_query($req))[0];
        return $achat;
        }

    function get_quant_achat($id)
        {
        $req = "SELECT quant FROM achat WHERE id_user =".$id;
        $quant = pg_fetch_row(pg_query($req))[0];
        return $quant;
        }

    function get_prod_achat()
        {
        $req = "SELECT quant FROM achat WHERE id_user =".$id;
        $prod = pg_fetch_row(pg_query($req))[0];
        return $prod;
        }
    function get_transaction_achat()
        {

        }

    function get_date_achat($id)
        {

        }

    function get_date_jour_achat($date)
        {

        }
    }
?>