#include "./lettre.h"
#include <stdlib.h>
#include <time.h>

lettre::lettre()
    {
    static bool init=false;
	if(init==false)
        {
        srand(time(NULL));
        init=true;
        }
    l = rand() % 26 + 65;
    }

lettre::lettre(char c)
    {
    if(c >= 'A' && c <= 'C')
        {
        l = c ;
        }
    else
        {
        if(c >= 'a' && c <= 'z')
            {
            l = c & 223;
            }
        else
            {
            l = 'A';
            }
        }
    }

char lettre::get_char()
    {
    char c;
    cache = '-';
    c = v?l:cache;
    return c;
    }

void lettre::set_visible(bool b)
    {
    v = b;
    }