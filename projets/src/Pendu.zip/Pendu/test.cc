#include "lettre.h"
#include <iostream>

int main()
    {
    std::cout<<"visible\tpas visible \n";
    for (int i = 0; i <=10; i++)
        {
        lettre l;
        l.set_visible(true);
        std::cout<<l.get_char()<<'\t';
        l.set_visible(false);
        std::cout<<l.get_char()<<'\n';
        }
    }