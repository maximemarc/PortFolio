#ifndef LETTRE
#define LETTRE

class lettre
	{
	private:
                char l;
                bool v;
                char cache;
		
	public:
		// Crée aléatoirement une lettre majuscule comprise entre A et Z
		// Par défaut, la lettre est visible
		lettre();

		// Crée une lettre majuscule comprise entre A et Z d'après la valeur
		// passé en paramètre. Si valeur minuscule, passage automatique
		// en majuscule, si autre valeur, la valeur 'A' est prise
		// Par défaut, la lettre est visible
		lettre(char);

		// Renvoie la lettre majuscule en tenant compte 
		// de sa visibilité
		char get_char();

                //permet de cacher ou montrer une lettre
                void set_visible(bool);
	};

#endif